sudo docker build -t ranacy .
sudo docker run -d -p 8386:8386 ranacy