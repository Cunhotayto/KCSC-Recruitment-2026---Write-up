sudo docker build -t christmas_gift .
sudo docker run -d -p 8386:8386 christmas_gift